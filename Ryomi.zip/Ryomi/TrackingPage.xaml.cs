﻿namespace Ryomi;

public partial class TrackingPage : ContentPage
{
	public TrackingPage()
	{
		InitializeComponent();
	}
}
