﻿namespace Ryomi;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}

