﻿using Microsoft.Maui.Controls;

namespace Ryomi
{
    public partial class MainPage : Shell
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
